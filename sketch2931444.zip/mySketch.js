function setup() {
  createCanvas(400, 400);
  fill('beige');
}

function draw() {
  background('black');
  
  noStroke();  //「線なし」
  
  ellipse(200, 170, 340, 180);
 

  stroke('black');   //  「線あり」
  strokeWeight(2);   // 線の太さ（2）
	
  ellipse(200, 200, 200, 80);
  circle(230, 200, 40);
  circle(170, 200, 40);
  triangle(100, 100, 0, 80, 100, 40);
  triangle(300, 100, 300, 40, 380, 80);
	strokeCap(ROUND);
  triangle(300, 100, 250, 110, 280, 50);
  triangle(300, 100, 330, 140, 360,90);
	square(290,80,30);
	
  // 線の太さを「10」
  strokeWeight(10);
  ellipse(150, 150, 10, 10);
  ellipse(245, 150, 10, 10);
}