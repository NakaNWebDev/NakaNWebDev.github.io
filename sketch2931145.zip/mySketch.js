function setup() {
  createCanvas(windowWidth, windowHeight);
  background(255);
}

function draw() {
  fill(random(256), random(256), random(256), random(50,201));
  noStroke();
  circle(random(windowWidth), random(windowHeight), random(10,41));	 

}
